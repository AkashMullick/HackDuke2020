const auth = require("./auth");
const tutorial = require("./tutorial");
const home = require("./home");

module.exports = { auth, tutorial, home };
